# Akshay Tours & Travels Website

Responsive single-page website for Akshay Tours & Travels.

## User-supplied vehicle images
The website includes the six images supplied in the conversation:
- Swift Dzire
- Innova Crysta
- Ertiga
- Force Traveller 17/20 Seater
- Tourist Bus
- WagonR

The images are stored locally in the `images/` folder, so they are included in the ZIP and do not depend on external image URLs.

## Publish on GitHub Pages
1. Create a new public GitHub repository.
2. Upload `index.html` and the `images` folder.
3. Open Settings → Pages.
4. Select Deploy from branch → `main` → `/root`.
5. Save and open the generated GitHub Pages URL.
